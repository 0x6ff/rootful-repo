#!/usr/bin/bash

for i in "$@"; do
    if [[ $i == *.deb ]]; then
        cp "$i" "/private/var/mobile/Library/Mobile Documents/com~apple~CloudDocs/Downloads/debs"
    fi
done

/usr/bin/dpkg.real "$@"
